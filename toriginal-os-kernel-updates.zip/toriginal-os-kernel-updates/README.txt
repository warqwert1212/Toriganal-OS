Toriginal OS kernel repo — drop-in updates
===========================================

Where each file goes (paths relative to your repo root):

  freeNT/include/trploader.h        -> root/freeNT/include/trploader.h
  freeNT/kernel/trploader.c         -> root/freeNT/kernel/trploader.c
  freeNT/kernel/syscall.c           -> root/freeNT/kernel/syscall.c
  freeNT/kernel/boot/boot64.s       -> root/freeNT/kernel/boot/boot64.s
  freeNT/kernel/boot/kernel64.ld    -> root/freeNT/kernel/boot/kernel64.ld
  sys_shell/shell.c                -> root/sys/shell/shell.c

What changed and why:

1. trploader.h / trploader.c
   - trp_file_header_t / TRP_MAGIC now defined once (in trploader.h)
     instead of duplicated independently in trploader.c and shell.c —
     that duplication was a real bug waiting to bite the moment either
     copy drifted.
   - trp_exec_bin() no longer kmalloc()'s a fresh, unpredictable address
     for a binary payload. Non-PIC compiled code has absolute addresses
     baked in at link time; landing at the wrong address corrupts memory
     or crashes on the first absolute reference. It now always loads at
     a fixed, pinned address (0x300000) — see kernel64.ld.

2. boot64.s
   - GDT only had 3 entries (null, kernel code, kernel data). But
     syscall_init() already programs STAR so that `sysretq` loads CS/SS
     from selectors 0x2B/0x23 — which didn't exist. The very first
     sysretq would have faulted. Added the two ring-3 GDT entries (plus
     one placeholder slot SYSRET's arithmetic needs but never loads) so
     this actually works. This bug was already latent in the codebase;
     nothing had ever exercised a real syscall round-trip before now.

3. kernel64.ld
   - Added a pinned, ASSERT-protected 1 MiB `.trp_code_area` section at
     0x300000 for loading .trp binary payloads. Pinned to a literal
     address (not "wherever .bss ends") so it doesn't shift every time
     the kernel is rebuilt with different code — that would silently
     invalidate every already-compiled .trp binary. The ASSERT turns
     "kernel grew into this reserved area" into a build failure instead
     of silent corruption.

4. syscall.c — real implementation, replacing the empty stub
   - Real entry stub (hand-written asm, disassembly-verified against the
     intended register handling — see the comment block at the top of
     the file for exactly what was and wasn't verified)
   - Real dispatch table (syscall_register_handler / syscall_dispatch)
   - Three working syscalls: SYS_WRITE (console output), SYS_EXIT
     (process termination), SYS_GETPID

5. shell.c
   - Uses the shared trp_file_header_t from trploader.h instead of its
     own independent (and driftable) copy.

IMPORTANT — NOT boot-tested
----------------------------
There is no QEMU in the sandbox this was built in, and no way to
install it (network egress blocked every source, including the
documented-as-allowed ones). Every change here was verified as
thoroughly as static tools allow: full kernel rebuilds succeeded clean
with zero errors/warnings introduced, the GDT math was hand-checked
against the AMD64 SYSCALL/SYSRET spec, and the syscall entry stub's
disassembly was checked instruction-by-instruction against the intended
register handling. None of that replaces an actual boot test. Boot this
in VirtualBox/QEMU before trusting it.
